/*
 * Copyright (C) 2020 
 * Authors: Ricardo Arguello, Misael Fernández
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.*
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package ec.gob.firmadigital.libreria.certificate.ec.anfac;

import static ec.gob.firmadigital.libreria.certificate.ec.anfac.CertificadoAnfAc37442.*;
import ec.gob.firmadigital.libreria.exceptions.EntidadCertificadoraNoValidaException;
import static ec.gob.firmadigital.libreria.utils.BouncyCastleUtils.certificateHasPolicy;

import java.security.cert.X509Certificate;

/**
 * Permite construir certificados tipo Certificado ANF AC a partir de
 * certificados X509Certificate.
 *
 * @author Misael Fernández, Jair Andres Semblantes Pinto
 */
public class CertificadoAnfAc37442Factory {

    public static boolean esCertificadoDeAnfAc37442(X509Certificate certificado) {
        return (certificateHasPolicy(certificado, OID_CERTIFICADO_PERSONA_NATURAL)
                || certificateHasPolicy(certificado, OID_CERTIFICADO_PERSONA_JURIDICA)
                || certificateHasPolicy(certificado, OID_CERTIFICADO_FUNCIONARIO_PUBLICO)
                || certificateHasPolicy(certificado, OID_SELLADO_TIEMPO));
    }

    public static CertificadoAnfAc37442 construir(X509Certificate certificado) throws EntidadCertificadoraNoValidaException {
        if (!esCertificadoDeAnfAc37442(certificado)) {
            throw new IllegalStateException("Este no es un certificado emitido por ANF AC Ecuador");
        }

        if (certificateHasPolicy(certificado, CertificadoAnfAc37442.OID_CERTIFICADO_PERSONA_NATURAL) || certificateHasPolicy(certificado, CertificadoAnfAc37442.OID_CERTIFICADO_PERSONA_NATURAL_TOKEN)) {
            return new CertificadoPersonaNaturalAnfAc37442(certificado);
        } else if (certificateHasPolicy(certificado, CertificadoAnfAc37442.OID_CERTIFICADO_PERSONA_JURIDICA) || certificateHasPolicy(certificado, CertificadoAnfAc37442.OID_CERTIFICADO_PERSONA_JURIDICA_TOKEN)) {
            return new CertificadoPersonaJuridicaAnfAc37442(certificado);
        } else if (certificateHasPolicy(certificado, CertificadoAnfAc37442.OID_CERTIFICADO_FUNCIONARIO_PUBLICO) || certificateHasPolicy(certificado, CertificadoAnfAc37442.OID_CERTIFICADO_FUNCIONARIO_PUBLICO_TOKEN)) {
            return new CertificadoFuncionarioPublicoAnfAc37442(certificado);
        } else if (certificateHasPolicy(certificado, CertificadoAnfAc37442.OID_SELLADO_TIEMPO)) {
            return new CertificadoSelladoTiempoAnfAc(certificado);
        } else {
            throw new EntidadCertificadoraNoValidaException("Certificado ANF AC Ecuador de tipo desconocido!");
        }
    }
}
