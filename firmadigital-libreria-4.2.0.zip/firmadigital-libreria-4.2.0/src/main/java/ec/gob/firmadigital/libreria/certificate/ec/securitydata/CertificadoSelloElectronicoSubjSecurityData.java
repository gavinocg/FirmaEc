/*
 * Copyright (C) 20206
 * Authors: Misael Fernández, Security Data
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.*
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package ec.gob.firmadigital.libreria.certificate.ec.securitydata;

import ec.gob.firmadigital.libreria.certificate.ec.CertificadoSelloElectronico;
import static ec.gob.firmadigital.libreria.certificate.CertificadoOids.Subj.OID_COMMON_NAME;
import java.security.cert.X509Certificate;

/**
 * Certificado de Miembro Empresa / Sello Electrónico emitido por Security Data.
 * Sigue la estructura de la resolución de ARCOTEL-2024-0176.
 *
 * @author Freddy Pico
 */
public class CertificadoSelloElectronicoSubjSecurityData extends CertificadoSubjSecurityDataImpl
        implements CertificadoSelloElectronico {

    public CertificadoSelloElectronicoSubjSecurityData(X509Certificate certificado) {
        super(certificado);
    }

    @Override
    public String getCommonName() {
        return getSubjectField(OID_COMMON_NAME);
    }
}
